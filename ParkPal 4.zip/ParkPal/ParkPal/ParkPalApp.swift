//
//  ParkPalApp.swift
//  ParkPal
//
//  Created by Luis Portilla on 10/7/23.
//

import SwiftUI

@main
struct ParkPalApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
