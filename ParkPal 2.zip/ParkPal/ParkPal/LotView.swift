//
//  LotView.swift
//  ParkPal
//
//  Created by Luis Portilla on 10/8/23.
//

import SwiftUI
import MapKit

struct CustomAnnotation: Identifiable {
    let id = UUID()
    let annotation: MKPointAnnotation
}

struct LotView: View {
    
    @State private var region = MKCoordinateRegion(
        center: CLLocationCoordinate2D(latitude: 32.7278641, longitude: -97.1117944),
        span: MKCoordinateSpan(latitudeDelta: 5.0, longitudeDelta: 5.0)
    )
    
    var annotations: [CustomAnnotation] = {
        var places = [CustomAnnotation]()
        
        let annotation1 = MKPointAnnotation()
        annotation1.coordinate = CLLocationCoordinate2D(latitude: 32.728, longitude: -97.114)
        places.append(CustomAnnotation(annotation: annotation1))
        
        let annotation2 = MKPointAnnotation()
        annotation2.coordinate = CLLocationCoordinate2D(latitude: 32.7285, longitude: -97.115)
        places.append(CustomAnnotation(annotation: annotation2))
        
        let annotation3 = MKPointAnnotation()
        annotation3.coordinate = CLLocationCoordinate2D(latitude: 32.7282, longitude: -97.1138)
        places.append(CustomAnnotation(annotation: annotation3))
        
        return places
    }()
    
    @State private var isFABMenuVisible: Bool = false
    @State private var showRedBoxes: Bool = false
    var lotName: String
    
    var body: some View {
        VStack {
            Text(lotName)
                .font(.title2)
                .padding()
            
            Map(coordinateRegion: $region)
            .frame(height: 200)
            
            if showRedBoxes {
                HStack {
                    ForEach(annotations, id: \.id) { _ in
                        Rectangle()
                            .fill(Color.red)
                            .frame(width: 40, height: 20)
                            .padding(5)
                    }
                }
            }
            
            Spacer()
            
            // FAB Menu items
            if isFABMenuVisible {
                ForEach(["Students 1", "Students 2", "Faculty 1", "Faculty 2"], id: \.self) { lot in
                    Button(action: {
                        if lot == "Faculty 1" {
                            withAnimation {
                                region.center = CLLocationCoordinate2D(latitude: 32.728685, longitude: -97.114870)
                                region.span = MKCoordinateSpan(latitudeDelta: 0.001, longitudeDelta: 0.001)
                                showRedBoxes = true
                            }
                        } else {
                            showRedBoxes = false
                        }
                    }) {
                        Text(lot)
                            .padding()
                            .background(Color.white)
                            .clipShape(Capsule())
                            .shadow(radius: 2)
                    }
                    .padding(.bottom, 10)
                }
            }
            
            // FAB Button
            Button(action: {
                withAnimation {
                    isFABMenuVisible.toggle()
                }
            }) {
                Image(systemName: "plus")
                    .font(.system(size: 24))
                    .padding(16)
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .clipShape(Circle())
            }
            .padding(.bottom, 20)
        }
    }
}

